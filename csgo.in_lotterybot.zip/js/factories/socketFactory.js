angular.module('gameApp').factory('socketFactory', function () {
	var socket = {};
	socket.cs = io('http//skinswin.ru:8303');
	
	return socket;
});
