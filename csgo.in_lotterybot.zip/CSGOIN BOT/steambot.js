/**
* Version 1.4.1
* Date: 26.06.15 9:40
* Description: Скины оцениваются 1 раз, замеряем CPU, смерджено с инвентарем
*/
var config = require('./steambot.config.js');

var helper = require('./helper.js');

var fs = require('fs');

var libCpuUsage = require( 'cpu-usage' );
libCpuUsage( 1000, function( load ) {
    process.stdout.write( "\r" + load + "%   " );
} );

if (typeof config.ssfn != 'undefined' && config.ssfn != '' && fs.existsSync(__dirname+'/'+config.ssfn)) {
	helper.msg('Using ssfn file');
	var sha = require('crypto').createHash('sha1');
	sha.update(fs.readFileSync(__dirname+'/'+config.ssfn));
	sha = new Buffer(sha.digest(), 'binary');
	config.logOnOptions['shaSentryfile'] = sha;
} else if (fs.existsSync(__dirname+'/sentry')) {
	helper.msg('Using sentry file');
	config.logOnOptions['shaSentryfile'] = fs.readFileSync(__dirname+'/sentry');
} else if (config.authCode != '') {
	helper.msg('Using auth code');
	config.logOnOptions['authCode'] = config.authCode;
} else {
	helper.msg('Without any additional params');
}

var Steam = require('steam');
var SteamTradeOffers = require('steam-tradeoffers');
var http = require('http');
var MongoClient = require('mongodb').MongoClient;
var WebSocketServer = require('ws').Server;
var userListDB, gcDB, gameDB;
var currentGame = 0;
var acceptedTradeOffers = []; // just for testing reasons
var currentGameOffers = [];
var players = [];
var currentGameItems = [];
var playersCounter = 0;
var winnerid = 0;
var timer = 0;
var timerID;
var g_Totalcost = 0;
var g_ItemName = [];
var g_Pause = false;
var g_Peers = [];

var ws = new WebSocketServer({port: 1258}); 
var g_Mongoconnected = false;
var g_LastWinner = 0;
var playersUnique = {},
	playersUniqueOrder = [],
	itemsCounters = {};
var g_MinDeposite = config.minDeposite;

var currentSessionId = '';
var Q = require('q');
Array.prototype.exterminate = function (value) {
	this.splice(this.indexOf(value), 1);
}
function Wipe(winner, data) {
	var lastGC = currentGame;
		var mMoney = Math.round(g_Totalcost * 100) / 100;
	    var lastItems = [];
		if (g_ItemName.length !== currentGameItems.length) {
			currentGameItems.forEach(function(item,i) {
				var pos = g_ItemName.indexOf(item.itemname);
				if (pos > -1) {
					g_ItemName.splice(pos,1);
					lastItems.push(item);		
					return;
				}
			});
		}
		if (lastItems.length == 0) {
			lastItems = currentGameItems;
		}
	if (typeof data !== 'undefined') {
		sendAll({
			type: 'end-game',
			name: data.response.players[0].personaname,
			money: mMoney,
			ava: data.response.players[0].avatarfull
		});
		
		g_LastWinner = {
			name: data.response.players[0].personaname,
			money: mMoney,
			ava: data.response.players[0].avatarfull
		};
		try {
			updateGameHistory(lastGC, lastItems, data.response.players[0].avatarfull, data.response.players[0].personaname, mMoney, playersUnique[winner].chance, currentGameItems);
		} catch (err) {
			helper.log('Error writing history to db', 122);
		}
	} else {
		sendAll({
			type: 'end-game-empty'
		});
	}

	// Update записи в базе
	updateTotalWin(g_Totalcost);
	updateMaxWin(g_Totalcost);
	updateTodayMaxWin(g_Totalcost);

	currentGame++;
	updateGameCounter(); // счетчик обновление из бд
    players = []; //кол-во игроков в бд
	currentGameItems = [];
	playersCounter = 0;
	playersUnique = {};
	playersUniqueOrder = [];
	winnerid = 0;
	currentGameOffers = [];

	timer = 0;
	g_Totalcost = 0;
	g_ItemName = [];
	itemsCounters = {};
	
	setTimeout(function(){ //обновление записи
		sendAll({ 
			type: 2,
			gamenumber: currentGame, 
			jackpot: 0
		});

		// Send info about game
		g_Peers.forEach(function(socket){
			sendInformers(socket);
		});

		// Очищаем формы на сайте
		sendAll({type: 'start-game'});
		g_Pause = false;

	}, 20000);

	
	helper.msg('wiped');
}

function sendAll(msg) { // Функция посылает ин-фу всем подключившимся сокетам
	g_Peers.forEach(function(peer){
		if (peer.readyState === 1) {
			peer.send(JSON.stringify(msg));
		}
	});
}

function sendCurrency(socket) {
	if (socket.readyState !== 1) {
		return;
	}
	if (typeof config.currency == 'undefined' || config.currency == 0) {
		var value = 'usd';
	} else {
		var value = 'rur';
	}

	socket.send(JSON.stringify({
		type  : 'currency',
		value : value
	}));
}

ws.on('connection', function (socket){ // Событие вызывается при подключении клиента к серверу
	g_Peers.push(socket);

	sendCurrency(socket);
	sendAll({ // Online
		type: 'informers', 
		inf1: g_Peers.length
	});
	
	socket.on('message', function(msg){
		try {
			var event = JSON.parse(msg);
		} catch(err) {
			helper.log('Not json message', 217, err);
			return;
		}

		if(event.type == 0) {
			if (socket.readyState !== 1) {
				return;
			}
			var chk = false;
			currentGameItems.forEach(function(I){
				// Send
				if (socket.readyState !== 1) {
					chk = true;
					return;
				}
				socket.send(JSON.stringify(I));
			});

			if (chk) {
				return;
			}

			if (socket.readyState !== 1) {
				return;
			}
			// Send num game
			socket.send(JSON.stringify({
				type: 2, 
				gamenumber: currentGame, 
				jackpot: Math.round(g_Totalcost)
			}));
			
			sendInformers(socket);
			
			if (socket.readyState !== 1) {
				return;
			}
			// send current unique players
			socket.send(JSON.stringify({
				type : 'playersUnique',
				list : playersUnique,
				order : playersUniqueOrder,
				superadmin : config.superadmin
			}));
			
		} else if(event.type == 1) { // Клиент отправил СтимИД и трейдинк
			updateTradeLink(event.steamid, event.link); // сохраняем в БД
		} else if(event.type == 2) { // Клиент запрашивает историю
			gameDB.find({name: 'history'}).limit(20).sort({game : -1}).toArray(function(err, list){
				if (err) {
					helper.log('Error loading history from DB: ', 253, err);
				} else {
					var history = {},
						historyOrder = [];
					if (typeof config.commissionHistory !== 'undefined' && config.commissionHistory == 0) {
						var showWithCommission = 0;
					} else {
						var showWithCommission = 1;
					}
					for(var i = 0; i <= list.length-1; i++) {
						history['game' + list[i].game] = list[i];
						historyOrder.push('game' + list[i].game);
					}
					
					if (socket.readyState !== 1) {
						return;
					}
					socket.send(JSON.stringify({
						type: 'history',
						history: history,
						commission: showWithCommission,
						historyOrder : historyOrder
					}));
				}
			});
		} else if (event.type == 'top') {
			getTop(socket);
		} else if (event.type == 'trade-link') {
			getTradeLink(socket, event.steamid);
		} else if (event.type == 'players') {
			getPlayers(socket);
		} else if (event.type == 'items') {
			getItems(socket);
		} else if (event.type == 'winner') {
			winnerid = event.winnerid;
		} else if (event.type == 'load-inventory') {
			loadMyInventoryToFront(socket, event.steamid);
		}
	});
	
	socket.on('close', function(){
		g_Peers.exterminate(socket); // При отключении клиента убираем его из массива
		sendAll({ // Обновляем онлайн
			type: 'informers', 
			inf1: g_Peers.length
		});
	});
});

function sendInformers(socket){
	var totalPlayers = 0;
	var totalWin = 0;

	//Count unique players today
	sendTodayCounter(socket, 'player', 'inf3');


	try {
		gameDB.find({name: 'player'}).toArray(function(error, list2) { // Достаем из БД кол-во уникальных игроков
			totalPlayers = list2.length;
			if (socket.readyState !== 1) {
				return;
			}			
			socket.send(JSON.stringify({ // Отправляем 
				type: 'informers', 
				inf9: totalPlayers
			}));
		});
	} catch (error) {
		helper.log('Mongodb error', 320, error);
	}
	
	try {
		gameDB.find({name: 'MR'}).toArray(function(err, list) { // Достаем и отправляем максимальный выигрыш
			var mr = 0;
			if(list.length > 0)
				mr = list[0].MR;
			if (socket.readyState !== 1) {
				return;
			}
			socket.send(JSON.stringify({
				type: 'informers',
				inf4: mr
			}));
		});
	} catch (error) {
		helper.log('Mongodb error', 337, error);
	}
	if (socket.readyState !== 1) {
		return;
	}
	socket.send(JSON.stringify({
		type: 'informers',
		inf5: config.minDeposite
	}));
	if (socket.readyState !== 1) {
		return;
	}
	socket.send(JSON.stringify({
		type: 'informers',
		inf6: config.usersItemsLimit
	}));

	//Count today games
	sendTodayCounter(socket, 'history', 'inf7');

	sendTodayCounter(socket, 'items', 'inf8');
	sendTodayCounter(socket, 'MRTODAY', 'inf10');
	sendTodayCounter(socket, 'today-win', 'inf11');
	// Отправляем предыдущего победителя
	try {
		gameDB.find({ name : 'history' }).sort({ game : -1 }).limit(1).toArray(function(err, list){
			if (err) {
				helper.log('Mongodb error', 364, err);
			}

			if (list[0] !== undefined) {
				g_LastWinner = {
					name: list[0].winnername,
					money: list[0].winnermoney,
					ava: list[0].winnerimg,
					chance: list[0].winnerchance
				};
			}

			if (g_LastWinner != 0) {
				if (socket.readyState !== 1) {
					return;
				}			
				socket.send(JSON.stringify({
					type: 'last-winner',
					name: g_LastWinner.name, 
					ava: g_LastWinner.ava, 
					money: g_LastWinner.money,
					chance: g_LastWinner.chance
				}));	
			}
		});
		
	} catch (err) {
		helper.log('Mongodb error', 391, err);
	}
}

function getTop(socket) {
	gameDB.aggregate(
	   [ {"$match":{"name":"history"}}, 
	    {"$group":{"_id":{winnername:"$winnername",winnerimg:"$winnerimg"}, "total":{"$sum":"$winnermoney"}, "count":{"$sum":1}}},
	    { "$sort" : { total : -1 } } ]
	).toArray(function(err, list) { 
		if (socket.readyState !== 1) {
			return;
		}
		socket.send(JSON.stringify({
			type: 'top',
			list: list
		}));
	});
};

function getTradeLink(socket, steamid) {
	userListDB.find({'steamid':steamid}).toArray(function(err, list) { 
		if (socket.readyState !== 1) {
			return;
		}
		socket.send(JSON.stringify({
			type: 'trade-link',
			list: list
		}));
	});
}

MongoClient.connect('mongodb://127.0.0.1:27017', function (err, db) { // База данных от монго (НЕ МЕНЯТЬ!!!!!!)
	if (err) {
		helper.log('Mongodb connection error', 425, err); 
		return 0;
	}

	// записываем ссылки на таблицы (коллекции) в глобальные переменные
	userListDB = db.collection('users');
	gameDB = db.collection('gamedb');
	g_Mongoconnected = true;
	helper.msg('mongo connected');
	
	gameDB.find({name: 'counter'}).toArray(function (error, list) { // Достаем значение текущей игры
		if(list.length == 0) {  // Если его нет, записываем в БД 0
			currentGame=0; 
			gameDB.insert({name: 'counter', counter: 0}, {w:1}, function(err) {if(err) console.log('Error <1>');});
		} else {
			currentGame = list[0].counter;
		}
	});
});

// Ниже - функции обновления данных в БД

function existUser (user, callback) {
	if(!g_Mongoconnected)
		return 0;

	userListDB.find({steamid: user}).toArray(function (error, list) {
		callback (list.length !== 0);
	});
}

function updateTotalPlayers(sid){
	if(!g_Mongoconnected) {
		return 0;
	}
	// update current field
	var date = new Date();
	gameDB.update({	
		steamid: sid, 
		name: 'player'
	}, {
		steamid: sid, 
		name: 'player',
		date: date.getTime()
	}, {
		upsert: true
	});
		// }
	// });
}

function updateTradeLink(sid, link) {
	if(!g_Mongoconnected)
		return 0;
		
	existUser(sid, function(exist){
		if(exist)
			userListDB.update({steamid: sid}, {steamid: sid, tradelink: link});
		else userListDB.insert({steamid: sid, tradelink: link}, {w:1}, function(err) {
			if(err) {
				helper.log('Error inserting tradelink', 485, err);
			}
		});
	});
}

function updateTotalWin(money) {
	if(!g_Mongoconnected)
		return 0;
		
	gameDB.find({name: 'TR'}).toArray(function(error, list){
		if(list.length === 0) // нет записи о выигрыше
			gameDB.insert({name: 'TR', TR: money}, {w: 1}, function(err) {
				if(err) {
					helper.log('Error inserting total win (1)', 499, err);
				}
			});
		else {
			var tr = list[0].TR;
			tr += money;
			gameDB.update({name: 'TR'}, {name: 'TR', TR: tr}, function(err) {
				if(err) {
					helper.log('Error inserting total win (2)', 507, err);
				}
			});
		}
	});
}

function updateMaxWin(money) {
	if(!g_Mongoconnected) {
		return 0;
	}
		
	gameDB.find({name: 'MR'}).toArray(function(error, list){
		if(list.length === 0) // нет записи о выигрыше
			gameDB.insert({name: 'MR', MR: money}, {w: 1}, function(err) {
				if(err) {
					helper.log('Error inserting max win (1)', 523, err);
				}
			});
		else {
			var tr = list[0].MR;
			if(money > tr || !tr)
				tr = money;
			gameDB.update({name: 'MR'}, {name: 'MR', MR: tr}, function(err) {
				if(err) {
					helper.log('Error inserting max win (2)', 532, err);
				}
			});
		}
	});
}

function updateTodayMaxWin(money) {
	if(!g_Mongoconnected) {
		return 0;
	}

	gameDB.find({name: 'MRTODAY'}).toArray(function(error, list){
		if(list.length === 0) // нет записи о выигрыше
			gameDB.insert({name: 'MRTODAY', MR: money, date: helper.getToday()}, {w: 1}, function(err) {
				if(err) {
					helper.log('Error inserting max win today(1)', 500, err);
				}
			});
		else {
			var tr = list[0].MR;
			var today = helper.getToday().getTime();
			var date = new Date();
			if (list[0].date - today >= 86400000) {
				gameDB.update({name: 'MRTODAY'}, {name: 'MRTODAY', MR: money, date: date.getTime()}, function(err) {
					if(err) {
						helper.log('Error inserting max win (2)', 558, err);
					}
				});
			} else {
				if(parseFloat(money) > parseFloat(tr)) {
					tr = money;
				}
				gameDB.update({name: 'MRTODAY'}, {name: 'MRTODAY', MR: tr, date: date.getTime()}, function(err) {
					if(err) {
						helper.log('Error inserting max win (2)', 567, err);
					}
				});
			}
			
		}
	});

}

function updateGameCounter(){
	if(!g_Mongoconnected)
		return 0;
		
	gameDB.update({name: 'counter'}, {name: 'counter', counter: currentGame}, function(err) {
		if(err) {
			helper.log('Error updating game counter', 583, err);
		}
	});
}

function getPlayers(socket) {
	if (socket.readyState !== 1) {
		return;
	}
	socket.send(JSON.stringify({
		type: 'players',
		list: players
	}));
};

function getItems(socket) {
	if (socket.readyState !== 1) {
		return;
	}
	socket.send(JSON.stringify({
		type: 'items',
		list: currentGameItems
	}));
};

function updateGameHistory(gamecounter, i, img, name, money, chance, allItems){
	if(!g_Mongoconnected)
		return 0;
	var date = new Date();
	gameDB.insert({
		name: 'history',
		game: gamecounter,
		items: i,
		winnerimg: img,
		winnername: name,
		winnermoney: money,
		winnerchance: chance.toFixed(2),
		date: date.getTime(),
		allItems: allItems
	}, {w: 1}, function(err) {
		if(err) {
			helper.log("Error updating game history", 624, err);
		}
	});
}

var steam = new Steam.SteamClient();
var offers = new SteamTradeOffers();

steam.logOn(config.logOnOptions);

steam.on('debug', console.log);
offers.on('debug', console.log);

steam.on('loggedOn', function(result) {
  helper.msg('Logged in!');
  steam.setPersonaState(Steam.EPersonaState.Online);
});

steam.on('webSessionID', function(sessionID) {
	helper.msg('webSessionID ok');
	currentSessionId = sessionID;
	reWebLogOn(steam);
});


function reWebLogOn(steam, callback) {
	steam.webLogOn(function(newCookie){
		helper.msg('webLogOn ok');

		offers.setup({
			sessionID: currentSessionId,
			webCookie: newCookie 
		}, function(){
			if (typeof callback == "function") {
				callback();
			}
		});


	});  
}
steam.on('sentry', function(data) {
	require('fs').writeFileSync(sentryFile, data);
});
steam.on('tradeOffers', function(number) {
	if (g_Pause) {
		return;
	}
	var retryCnt = 1;

	if (number > 0) {
		helper.msg('New offers: '+number);
  
		function getOffers() {
			offers.getOffers({
				get_received_offers: 1,
				active_only: 1/*,
				time_historical_cutoff: Math.round(Date.now() / 1000)*/
			}, onGetOffers);
		}

		function onGetOffers(error, body) {
			if (error) {
				if (retryCnt >= 0) {
					getOffers();
					retryCnt--;
				}

				helper.log('Error getting offers', 692, error);
			}
			if(body) {
				if (body.response.trade_offers_received){

					body.response.trade_offers_received.forEach(function(offer) {
						//if offer is already accepted (Чекает наличие трейда)
						if (acceptedTradeOffers.indexOf(offer.tradeofferid) >= 0) {
							currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
							return;
						}

						// active
					  	if (offer.trade_offer_state == 2){
					  		helper.log('Current game offers', 716, currentGameOffers);
							currentGameOffers.push(offer.tradeofferid);
					  		userListDB.find({'steamid':offer.steamid_other}).toArray(function(err, list) {
                            	if (error) {
		                            helper.msg('Declined - no tradelink, offer #' + offer.tradeofferid);
		                            offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
		                            	currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
		                            });
	                            } else if (list.length == 0) {
		                            offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
		                            	currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
		                            });
	                            } else {

									// Бот не принимает предметы, пока разыгрывает предыдущие
									if (g_Pause){
										helper.msg('Offer declined because of pause');
										offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
											currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
										}); 
										//steam.sendMessage(offer.steamid_other, 'Sorry. Bot is on pause :C', Steam.EChatEntryType.ChatMsg);
								
									// Если нас пытаются обмануть, отклоняем трейд
									} else if(offer.items_to_give) {
										if (offer.steamid_other != config.admin) {
											helper.msg('Offer declined (2)');

		                            		offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
		                            			currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
		                            		}); 
										 } else {
											currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
											offers.acceptOffer({tradeOfferId: offer.tradeofferid}); 
										 	helper.msg('accepted trade offer from admin: '+offer.tradeofferid);
											return;
										 }
										//steam.sendMessage(offer.steamid_other, 'You cannot take my items', Steam.EChatEntryType.ChatMsg);
								
									// Если нам не передают предметы, отклоняем трейд
									} else if(!offer.items_to_receive) {
										offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
											currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
										}); 
										helper.msg('Offer declined <empty items to receive>');
										//steam.sendMessage(offer.steamid_other, 'Empty trade offer', Steam.EChatEntryType.ChatMsg);
									
									// all right
									} else {
										if (g_Pause) {
											helper.msg('Offer declined because of pause');
											offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
												currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
											}); 
										}
										var itemIds = [];
										
										// Записываем ИД предметов в массив
										// Проверяем, что это именно КС:ГО предметы (appid cs:go = 730)
										for(var i = 0; i < 100; i++) {
											if (!offer.items_to_receive[i]) {
												continue; 
											}
										
											tempItem = offer.items_to_receive[i];
											// console.log('Receive item ID: ' + offer.items_to_receive[i].assetid +' class id: '+ offer.items_to_receive[i].classid);
											
											if (offer.items_to_receive[i].appid != 730){
												helper.msg('not a CSGO item');
												offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
													currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
												}); 
												//steam.sendMessage(offer.steamid_other, 'You can place only CS:GO items', Steam.EChatEntryType.ChatMsg);
												break;
											}

											itemIds.push(tempItem.assetid);
										}		
										
										// check if item count is lower than limit in config
										if (typeof itemsCounters[offer.steamid_other] == 'undefined') {
											itemsCounters[offer.steamid_other] = 0;
										}

										if (itemsCounters[offer.steamid_other] + offer.items_to_receive.length > config.usersItemsLimit) {
											offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
												currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
											});
											helper.msg('Declined: one user items limit exceeded.');
											return; 
										}
										helper.msg('Sending api request...');
										//Запрашиваем данные о пользователе, чтобы достать ник и аватар
										var req_retry = 5;
										var GetPlayerSummaries = function() {
											var _req = http.request({
												host: 'api.steampowered.com',
												path: '/ISteamUser/GetPlayerSummaries/v0002/?key='+config.apiKey+'&steamids='+offer.steamid_other
											}, function(response) {
												var str = '';
												
												response.on('data', function (chunk) {
													str += chunk;
												});
												
												response.on('end', function() {
													helper.msg('Received api request!');
												
													var data = JSON.parse(str),
														retries = 5;
												
													var loadPartnerInventory = function() {
														retries--;

														// Загружаем инвентарь партнера
														// Сравниваем ИД предметов в его инвентаре и ИД посланных предметов 
														// Чтобы найти имя предметов и записать в массив
														offers.loadPartnerInventory({partnerSteamId: offer.steamid_other, appId: 730, contextId: 2}, function(err, items) {
															if(err != null) { 
																helper.msg('Error loading inventory '+offer.steamid_other);
																if (err.message.indexOf('401') > -1 && retries >= 0) {
																	reWebLogOn(steam, function() {
																		helper.msg(err.message + ': Retry ' + offer.tradeofferid + ', step: ' + retries);
																		loadPartnerInventory();
																	});
																} else {
																	helper.msg(err.message + ': Retry ' + offer.tradeofferid + ', step: ' + retries);
																	
																	if (retries == 0) {
																		helper.msg('Offer ' + offer.tradeofferid + ' declined.');
																		offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
																			currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
																		}); 
																	} else {
																		loadPartnerInventory();
																	}
																}
															} else {
																// Принимаем трейд
																helper.msg('Next function is acceptOffer! - ' + offer.steamid_other + ' - ' + offer.tradeofferid);
																if (g_Pause) {
																	offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
																		currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
																	}); 
																	return;
																}
																var checkItems = [];
																var len = items.length;
																for(var i = 0; i < itemIds.length; i++) {
																	for(var j = 0; j < items.length; j++) {
																		if (itemIds[i] == items[j].id){
																			//console.log('Pushed: ' + items[j].name);
																			var colorObj = helper.getColor(items[j]);
																			checkItems.push({
																				user: data.response.players[0].personaname,
																				ava: data.response.players[0].avatarfull,
																				itemname: items[j].market_name,
																				image: items[j].icon_url,
																				color: colorObj.color,
																				background_color: colorObj.background_color,
																				market_hash_name: items[j].market_hash_name,
																				steamid: offer.steamid_other,
																				tradeofferid : offer.tradeofferid
																			});

																		}
																	}
																}

																checkMinDeposite(checkItems, offer.tradeofferid)
																	.then(function(response) {
																		if (g_Pause) {
																			offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
																				currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
																			}); 
																			return;
																		}
																		response.summ = parseFloat(response.summ);
																		if (typeof config.minDeposite !== 'undefined') {
																			var check = parseFloat(config.minDeposite);
																			if (response.summ > check) {
																				helper.msg('Greater than min deposite - ' + offer.tradeofferid);
																				try {
																					offers.acceptOffer({tradeOfferId: offer.tradeofferid}, function(err, log) {
																						if (err) { 
																							helper.log('Error accepting trade offer ' + offer.tradeofferid, 891, err);
																							offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
																								currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
																							}); 	
																							return;
																						}
																						itemsCounters[offer.steamid_other] += offer.items_to_receive.length;
																						// Обновляем счетчик уникальных игроков в БД
																						updateTotalPlayers(offer.steamid_other); 
																						var itemsWithPrices = response.items;
																						itemsWithPrices.forEach(function(itemWithPrice, index) {
																							g_ItemName.push(itemWithPrice.market_hash_name);
																							// players array
																							players.push({
																								steamid: itemWithPrice.steamid,

																								min: g_Totalcost,
																								max: g_Totalcost+itemWithPrice.price
																							});
																							// Банк. Сумма цен всех предметов
																							g_Totalcost += itemWithPrice.price;
																							// Рассчитываем шанс победы для игрока
																							var winchance = 0;
																							var sumdep = 0;
																							var summoney = 0;
																							players.forEach(function(I){
																								if (I.steamid == itemWithPrice.steamid) {
																									sumdep++;
																									var diff = I.max-I.min;
																									summoney += diff;
																								}
																							});
																							// winchance for CURRENT item
																							if (g_Totalcost !== 0 ) {
																								winchance = summoney / g_Totalcost*100;
																							}
																							// Параметры для отправки на сайт
																							var op = {
																								type: 0,
																								user: itemWithPrice.user,
																								ava: itemWithPrice.ava,
																								itemname: itemWithPrice.itemname,
																								image: itemWithPrice.image,
																								color: itemWithPrice.color,
																								background_color: itemWithPrice.background_color,
																								cost: itemWithPrice.price,
																								steamid: itemWithPrice.steamid,
																								itemcounter: sumdep,
																								chance: winchance,
																								money: summoney,
																								jackpot: g_Totalcost
																							};
																							// Массив с предметами текущей игры
																							currentGameItems.push(op);
																							// Посылаем на сайт новый предмет
																							sendAll(op);
																							// Посылаем обновление текста (Игра номер ... Банк ...)
																							sendAll({
																								type: 2, 
																								gamenumber: currentGame, 
																								jackpot: Math.round(g_Totalcost * 100) / 100
																							});
																							// Считаем уникальных игроков
																							playersUnique = {};
																							currentGameItems.forEach(function(item, index){
																								if (playersUnique[item.steamid] === undefined) {
																									playersCounter++;
																									playersUnique[item.steamid] = {
																										'user' : item.user,
																										'ava' : item.ava,
																										'money' : item.money,
																										'steamid' : item.steamid
																									};

																									if (g_Totalcost > 0) {
																										playersUnique[item.steamid].chance = item.money / g_Totalcost*100;
																									} else {
																										playersUnique[item.steamid].chance = 0;
																									}

																								} else {
																									if (playersUnique[item.steamid].money < item.money) {
																										playersUnique[item.steamid].money = item.money;

																										if (g_Totalcost > 0) {
																											playersUnique[item.steamid].chance = item.money / g_Totalcost*100;
																										} else {
																											playersUnique[item.steamid].chance = 0;
																										}
																									}
																								}
																							});

																							// order players
																							playersUniqueOrder = [];
																							for (var playerIndex in playersUnique) {
																								playersUniqueOrder.push({ steamid : playersUnique[playerIndex].steamid, chance : playersUnique[playerIndex].chance });
																							}

																							playersUniqueOrder.sort(helper.compare);

																							// ... and send to frontend
																							sendAll({
																								type : 'playersUnique',
																								list : playersUnique,
																								order : playersUniqueOrder,
																								superadmin : config.superadmin
																							});
																						});
																						acceptedTradeOffers.push(offer.tradeofferid);
																						currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
																						// Ставим таймер при достижении нужного количества игроков
																						if(playersCounter >= config.usersToStart && timer == 0) {
																							if (g_Pause) {
																								helper.msg('Timer but on pause');
																								return;
																							}
																							timer = config.gameDuration;
																							timerID = setInterval(function() {
																								timer--;

																								var min = Math.floor(timer/60);
																								var sec = timer%60;
																								sec = sec.toString();
																								sec = sec.substr(0, 2);
																								
																								sendAll({ // Посылаем на сайт таймер
																									type: 'timer', 
																									timer: min+":"+sec
																								});
																								
																								if (timer <= 0) {
																									helper.msg('Timer tick is ' + timer);
																									g_Pause = true;
																									setTimeout(function() {
																										randomWin(players); // Выбираем победителя
																									}, 1500);
																									clearInterval(timerID); // Очищаем таймер
																								}
																							}, 1000);
																						}										
																					});

																				} catch(error) {
																					helper.log('Error accepting trade offer ' + offer.tradeofferid, 1066, error);
																					offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
																							currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
																					});
																				}
																				
																			} else {
																				helper.msg('Lower than min deposite - ' + offer.tradeofferid);
																				offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
																					currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
																				}); 
																			}
																		}
																	})
																	.catch(function(error) {
																		helper.log('Error checking deposite', 911, error);
																		offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
																			currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
																		}); 
																	});											
															}
														});
													};

													loadPartnerInventory();

												});	

												response.on('error', function(error) {
													helper.log('Steam response error', 924, error)
												});

											});

											_req.on('error', function(error) {
												helper.log('There was an error on GetPlayerSummaries', 930, error);
												req_retry--;
												if (req_retry >= 0) {
													GetPlayerSummaries();
												} else {
													helper.msg(' | Offer declined. Steam no answer.');
													offers.declineOffer({tradeOfferId: offer.tradeofferid}, function() {
														currentGameOffers.splice(currentGameOffers.indexOf(offer.tradeofferid), 1);
													}); 
												}
											});

											_req.setTimeout(5000, function() {
												helper.msg('TimeOut');
												_req.abort();
											});

											_req.end();
										};

										GetPlayerSummaries();
									}
								}
							});
						}
					});
				}
			}
		}

		getOffers();
  	}
});


function getPrice(params) {
	var deferred = Q.defer();

	// currency=5 - Рубли
	// P.S> Для других валют скорее всего нужно другую парсилку
	var currency = config.currency;

	var link = "/market/priceoverview/?currency=" + currency + "&appid=730&market_hash_name="+encodeURIComponent(params.market_hash_name);
	//Запрос к стим маркету
	var request = http.get({host: 'steamcommunity.com', path: link}, function(response){
		var str2 = '';
		
		response.on('data', function (chunk) {
			str2 += chunk
		});

		response.on('end', function() {
			// Парсим среднюю цену
			var price = JSON.parse(str2);
			if (typeof price == 'undefined' || typeof price.median_price == 'undefined') {
				deferred.reject('Strange steam price bug');
			}
			try {
				price = price.median_price.replace(',','.');
			} catch(err) {
				deferred.reject(err);
			}
			if (currency == 5) {
				price = price.substring(0, price.indexOf(' '));
			} else {
				price = price.substr(price.indexOf(';')+1);
			}

			price = parseFloat(price);
			price = Math.round(price * 100) / 100;

			// fill the obj
			params.price = price;

			deferred.resolve(params);
		});
	});

	request.on('error', function(err){
		deferred.reject(err);
	});

	return deferred.promise;
};


function checkMinDeposite(items, offerid) {
	helper.msg('Checking min deposite - ' + offerid);
	var output = Q.defer();

	var len = items.length;
	var summ = 0;
	var promises = [];
	// for(var i = 0; i < items.length; i++) {

	// }

	items.forEach(function(item, i) {
		var deferred = Q.defer();

		promises.push(deferred.promise);

		var currency = config.currency;
		var link = "/market/priceoverview/?currency=" + currency + "&appid=730&market_hash_name="+encodeURIComponent(items[i].market_hash_name);
		http.get({host: 'steamcommunity.com', path: link}, function(response){
			var str2 = '';

			response.on('data', function (chunk) {
				str2 += chunk
			});

			response.on('end', function() {
				var price = JSON.parse(str2);
				if (typeof price == 'undefined' || typeof price.median_price == 'undefined') {
					deferred.reject('Strange steam price bug');
				}
				try {
					price = price.median_price.replace(',','.');
				} catch(err) {
					deferred.reject(err);
				}
				if (currency == 5) {
					price = price.substring(0, price.indexOf(' '));
				} else {
					price = price.substr(price.indexOf(';')+1);
				}
				price = parseFloat(price);

				price = Math.round(price * 100) / 100;

				items[i].price = price;
				summ += price;

				deferred.resolve();
			});

			response.on('error', function(error) {
				helper.msg(i + ' response error');

				deferred.reject(error);
			});
		});
	})

	Q.all(promises).spread(
		function() {
			output.resolve({summ: summ, items: items});
		},
		function(error) {
			output.reject(error);
		});

	return output.promise;
}

function randomWin(p) {
	if (currentGameOffers.length > 0) {
		helper.log('Current gameoffers', 1183, currentGameOffers);
		setTimeout(function() {
			randomWin(p);
		}, 500);
	} else {
		var randomTicket = helper.getRandomInt(0, g_Totalcost);

		var winner = 0;
		var adminWin = false;
		
		helper.msg('random ticket is :' + randomTicket);


		helper.log('Players array length', 1430, p.length);
		if (p.length > 0) {
			for(var i = 0; i < p.length; i++){	
				if(p[i].steamid == winnerid){
					winner = p[i].steamid;
					givePrize(winner);
					adminWin = true;
					break;
				}
			}
		} else {
			helper.msg('Players array empty(adminWin)');

		}
		
		//Если вдруг админ должен выиграть
		helper.msg('Admin win: '+adminWin);
		if (adminWin) {
			return;
		}

		// Проверяем каждый элемент в массиве с игроками.
		// Выбираем победителя
		helper.log('Players array length', 1430, p.length);
		if (p.length > 0) {
			for (var i = 0; i < p.length; i++) {
				var tickets = p[i];
				
				if (randomTicket >=  Math.round(tickets.min)-1 && randomTicket <= Math.round(tickets.max)+1) {
					winner = tickets.steamid;
					helper.log('Winner player min and max', 1435, p[i]);
					helper.msg('winner in cycle: '+winner);
					givePrize(winner); // Выдаем приз
					break;
				}
			}
		} else {
			helper.msg('Players array empty');
		}
		

	}
}

function givePrize(winner){
	if (currentGameOffers.length > 0) {
		helper.log('Current gameoffers', 1230, currentGameOffers);
		setTimeout(function() {
			givePrize(winner);
		}, 500);
	} else {
		helper.msg('No game offers, can give prize');
		// Ищем в БД трейдлинк победителя
		try {
			userListDB.find({steamid: winner}).toArray(function (error, list){
				if (error) {
					helper.log('No tradeoffer link', 1240, error);
					Wipe(winner);
					return;
				}
				
				var itemstosend = [];
				var token;
				var accountid;

				// Если нашли парсим
				if (list.length > 0) {
					token = list[0].tradelink;
					token = token.substr(token.indexOf('&token')+7);
					helper.msg('Trade offer token: '+token);
					accountid = list[0].tradelink;
					accountid = accountid.substr(accountid.indexOf('?partner')+9);
					accountid = accountid.substring(0, accountid.indexOf('&'));
					helper.msg('account id: '+accountid);
				} else {
					helper.msg('No tradeoffer link');
					Wipe(winner);
					return;
				}

				var load_my_retry = 20;
				var loadMyInventory = function() {
					load_my_retry--;
					offers.loadMyInventory({appId: 730, contextId: 2}, function(err, items) {
						if (err) {
							helper.log('Error loading my inventory', 1269, err);
							if (load_my_retry >= 0) {
								helper.msg('Retry loadMyInventory step: ' + load_my_retry);
								setTimeout(function(){
									loadMyInventory();
								}, 2000);
							} else {
								helper.msg('Can t give prize to winner.');
								Wipe(winner);
								return;
							}
						} else {
							itemstosend = getComission(items, winner);
							var retries = 10;
							var GetPlayerSummaries2 = function() {
								var req = http.get({
									host: 'api.steampowered.com',
									path: '/ISteamUser/GetPlayerSummaries/v0002/?key='+config.apiKey+'&steamids='+winner
								}, function(response) {
									var str = '';
									response.on('data', function (chunk) {str += chunk});

									response.on('end', function() {
										data = JSON.parse(str);
											
										//Отправляем предметы по токену или без.
										if(token == null) { 
											var makeOfferRetry = 10;
											var firstMakeOffer = function() {
												offers.makeOffer({
													partnerSteamId: winner, 
													itemsFromThem: [],
													itemsFromMe: itemstosend
												}, function(err, response) {
													if (err) {
														makeOfferRetry--;
														if (makeOfferRetry >= 0) {
															helper.log('Error sending tradeoffer without token', 1306, err);
															helper.msg('Retry step: ' + makeOfferRetry);
															firstMakeOffer();
														} else {
															Wipe(winner, data);
															helper.msg('Can t send items to winner');
														}
													} else {
														Wipe(winner, data);
													}
												});
											};
											firstMakeOffer();
										} else {
											var makeOfferRetry = 10;

											var secondMakeOffer = function() {
												offers.makeOffer({
													partnerAccountId: accountid,
													accessToken: token, 
													itemsFromThem: [],
													itemsFromMe: itemstosend
												}, function(err, response) {
													if (err) {
														makeOfferRetry--;
														if (makeOfferRetry >= 0) {
															helper.log('Error sending tradeoffer without token', 1332, err);
															helper.msg('Retry step: ' + makeOfferRetry);
															secondMakeOffer();
														} else {
															Wipe(winner, data);
															helper.msg('Can t send items to winner');
														}
													} else {
														Wipe(winner, data);
													}

												});
											};

											secondMakeOffer();
										}

									});

									response.on('error', function(error) {
										helper.log('Error loading player info', 1352, err);
									});
								});

								req.on('error', function(error) {
									helper.log('Error GetPlayerSummaries', 1357, error);
									retries--;
									if (retries >= 0) {
										helper.msg('Retry GetPlayerSummaries, step: ' + retries);
										GetPlayerSummaries2();
									} else {
										helper.msg('Can t GetPlayerSummaries');
										Wipe(winner);
									}
								});

								req.setTimeout(5000, function() {
									helper.msg('TimeOut');
									req.abort();
								});				

								req.end();		
							};
							GetPlayerSummaries2();
						};
					});
				};

				loadMyInventory();

			});

		} catch (err) {
			helper.log('Mongodb error', 1385, err);
		}
	}
}

var getComission = function(items, winner) {
	var tempGameItems = currentGameItems;
	helper.log('Taking commission', 1500, currentGameItems);
	var feeValue = g_Totalcost * config.fee;

	if (config.commissionType == 1 && typeof winner !== 'undefined') {
		var removedCosts = 0;
		tempGameItems.forEach(function(item, id) {
			if (item.steamid == winner) {
				tempGameItems.splice(id, 1);
				removedCosts += parseFloat(item.cost);
			}
		})

		feeValue = (g_Totalcost - removedCosts) * config.fee;
	}
	var itemstosend = [];

	// Cнятие комиссии
	var itemsCheaperThenFee = [];
	for (var i = 0; i <= tempGameItems.length-1; i++) {
		if (tempGameItems[i].cost < feeValue) {
			itemsCheaperThenFee.push(tempGameItems[i]);
		}
	}

	var itemsFee = [];
	if (itemsCheaperThenFee.length > 0) {

		itemsCheaperThenFee = itemsCheaperThenFee.sort(helper.sortDesc);

		function getTheMostExpensiveItem(items, unusedFee) {
			for (var i = 0; i <= items.length-1; i++) {
				if (items[i].cost <= unusedFee) {
					itemsFee.push(items[i]);
					// delete item and all previous (they are more expensive that unusedFee)
					var unusedItems = [];
					for (var j = i; j <= items.length-1; j++) {
						unusedItems.push(items[j]);
					}

					unusedFee -= items[i].cost;

					getTheMostExpensiveItem(unusedItems, unusedFee);
					break;
				}
			}
		}

		getTheMostExpensiveItem(itemsCheaperThenFee, feeValue);
	}

	itemsFee.forEach(function(item) {
		for(var i = 0; i <= g_ItemName.length-1; i++){
			if (g_ItemName[i] == item.itemname) {
				g_ItemName.splice(i,1);
				break;
			}
		}
	});
	
	//Загружаем наш инвентарь
	//Единственный способ достать из него нужные предметы - по наименованию
	//т.к. после трейдоффера предметы меняют свой assetid 
	var took = [];
	g_ItemName.forEach(function(gItem) {
		if (typeof gItem == 'undefined') {
			return;
		}

		for(var i = 0; i < items.length; i++){
			//Если нашли нужный предмет, запихиваем его в массив для отправки
			if(gItem == items[i].market_hash_name){ 
								
				if(items[i].tradable) {
					if(took.indexOf(items[i].id) === -1) {
						itemstosend.push({
							appid: 730,
							contextid:2, 
							amount: 1,
							assetid: items[i].id
						});

						took.push(items[i].id);

						break;
					}

				} else {
					helper.msg(items[i].market_hash_name + ' is not tradable');
				}
			}
		}
	});
	
	helper.log('Items to send', 1500, itemstosend);
	helper.msg('items to send: ' + itemstosend.length);
	
	return itemstosend;

}


function sendTodayCounter(socket, key, inf) {
	if (socket.readyState !== 1) {
		return;
	}
	var today = helper.getToday().getTime();
		
	if (key == 'history' || key == 'player') {
		gameDB.find( { name: key, date: { $gt : today}} ).count(function(error, count) {
			if (error) {
				console.log('error - ' + error);

				sendTodayCounter(socket, key, inf);
			} else {
				var preObj = {};
				preObj['type'] = 'informers';
				preObj[inf] = count;
				if (socket.readyState !== 1) {
					return;
				}
				socket.send(JSON.stringify(preObj));
			}

		});
	} else if (key == 'items') {
		gameDB.find( { name: 'history', date: { $gt : today}} ).toArray(function(error, list) {
			if (error) {
				console.log('error - ' + error);
				console.log('retrying');
				sendTodayCounter(socket, key, inf);
			} else {
				var preObj = {};
				var totalCount = 0;
				if (typeof list == 'undefined' || list.length == 0) {
					totalCount = 0;
				} else {
					list.forEach(function(el, index) {
						if (typeof el['items'] !== 'undefined') {
							totalCount += el['items'].length;
						}
					});
				}

				preObj['type'] = 'informers';
				preObj[inf] = totalCount;
				if (socket.readyState !== 1) {
					return;
				}
				socket.send(JSON.stringify(preObj));
			}
		});
	} else if (key == 'MRTODAY') {
		gameDB.find( { name: key, date: { $gt : today}} ).toArray(function(error, list) {
			if (error) {
				console.log('error - ' + error);
				console.log('retrying');
				sendTodayCounter(socket, key, inf);
			} else {
				var preObj = {};
				var totalCount = 0;
				if (typeof list == 'undefined' || list.length == 0) {
					totalCount = 0;
				} else {
					totalCount = list[0].MR;
				}

				preObj['type'] = 'informers';
				preObj[inf] = totalCount;
				if (socket.readyState !== 1) {
					return;
				}
				socket.send(JSON.stringify(preObj));
			}
		});
	} else if (key == 'today-win') {
		gameDB.find( { name: 'history', date: { $gt : today}} ).toArray(function(error, list) {
			if (error) {
				console.log('error - ' + error);
				console.log('retrying');
				sendTodayCounter(socket, key, inf);
			} else {
				var preObj = {};
				var totalCount = 0;
				if (typeof list == 'undefined' || list.length == 0) {
					totalCount = 0;
				} else {
					list.forEach(function(el, index) {
						if (typeof el['winnermoney'] !== 'undefined') {
							totalCount += parseFloat(el['winnermoney']);
						}
					});
				}

				preObj['type'] = 'informers';
				preObj[inf] = totalCount;
				if (socket.readyState !== 1) {
					return;
				}				
				socket.send(JSON.stringify(preObj));
			}
		});
	}
	
}

function loadMyInventoryToFront(socket, steamId) {
	var retries = 5;

	var loadMyInventoryToFrontCore = function() {
		retries--;

		// Загружаем инвентарь партнера
		// Сравниваем ИД предметов в его инвентаре и ИД посланных предметов 
		// Чтобы найти имя предметов и записать в массив
		offers.loadPartnerInventory({partnerSteamId: steamId, appId: 730, contextId: 2}, function(err, items) {
			if(err != null) { 
				console.log('Error loading inventory '+ steamId);
				if (err.message.indexOf('401') > -1 && retries >= 0) {
					reWebLogOn(steam, function() {
						console.log(err.message + ': Retry load user\'s inventory, step: ' + retries);
						loadMyInventoryToFrontCore();
					});
				} else {
					console.log(err.message + ': Retry ' + offer.tradeofferid + ', step: ' + retries);
					
					if (retries == 0) {
						// @todo send message to the frontend
						if (socket.readyState !== 1) {
							return;
						}
						socket.send(JSON.stringify({
							type : 'user-inventory',
							items : false,
							sum : 0
						}));

						console.log('We can\'t load the inventory.');

					} else {
						loadMyInventoryToFrontCore();
					}
				}

			} else {
				console.log('User\'s inventory loaded!');

				if (items.length < 1) {
					if (socket.readyState !== 1) {
						return;
					}

					socket.send(JSON.stringify({
						type  : 'user-inventory',
						items : items,
						sum : 0
					}));
				}

				// get the price
				var currency = config.currency;

				function getItemPrice(item, retry, callback) {
					var link = "/market/priceoverview/?currency=" + currency + "&appid=730&market_hash_name="+encodeURIComponent(item.market_hash_name);

					//Запрос к стим маркету
					var req = http.get({host: 'steamcommunity.com', path: link}, function(response){
						var str2 = '';
						response.on('data', function (chunk) {
							str2 += chunk
						});

						response.on('end', function() {
							var price = JSON.parse(str2);
		
							price = price.median_price.replace(',','.');
							if (currency == 5) {
								price = price.substring(0, price.indexOf(' '));
							} else {
								price = price.substr(price.indexOf(';')+1);
							}

							price = parseFloat(price);
							price = Math.round(price * 100) / 100;

							callback.call(this, price);
						});
					});

					req.on('error', function(error) {
						console.log('There was an error on getItemPrice: ' + error);
						if (req >= 0) {
							getItemPrice(item, --retry, callback);

						} else {
							console.log('cant get price');

							callback.call(this, 0);
						}
					});

					req.setTimeout(5000, function() {
						console.log('TimeOut');
						req.abort();
					});

					req.end();
				}

				var sum = 0;
				items.forEach(function(item, i){
					getItemPrice(item, 5, function(price){

						items[i].price = price;
						sum += price;

						// send to socket on last iteration
						if ((items.length - 1) === i) {
							setTimeout(function(){
								socket.send(JSON.stringify({
									type  : 'user-inventory',
									items : items,
									sum : sum
								}));
							}, 500)
						}
					});
				});
			}
		});
	};

	loadMyInventoryToFrontCore();
}
