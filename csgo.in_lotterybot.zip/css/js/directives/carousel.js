angular.module('gameApp').directive('carousel', [function () {
	return {
		restrict: 'A',
		link: function (scope, iElement, iAttrs) {
			/*scope.$apply(function(scope){
              scope.datas.caroselWidth = iElement[0].offsetWidth;
            });
                */
           
		}
	};
}]);

