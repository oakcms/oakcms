﻿<? require('steamauth/steamauth.php'); 


	if(isset($_SESSION["steamid"])) {
include_once('steamauth/userInfo.php');}
?>
<!DOCTYPE html>
<html lang="ru" ng-app="gameApp">
  <head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	<title>CSCONTROL.RU	– Самая честная CS:GO рулетка!</title>

	<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

	<link href="css/ehrb9.css" rel="stylesheet" type="text/css">
	<link href="css/main.css" rel="stylesheet" type="text/css">
	<link href="css/reset.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="/css/ngDialog.css">
	<link rel="stylesheet" href="/css/ngDialog-theme-default.css">
	<link rel="stylesheet" href="/css/swiper.css">
	<link rel="stylesheet" href="//cdn.jsdelivr.net/angular.ng-notify/0.6.2/ng-notify.min.css">
	<style type="text/css" id="core-notify">.notify-corner{position:fixed;margin:20px;z-index:1050;}.notify-corner .notify-wrapper,.notify-corner .notify-container{position:relative;display:block;height:inherit;width:395px;margin:3px;}.notify-wrapper{z-index:1;position:absolute;display:inline-block;height:0;width:0;}.notify-container{display:none;z-index:1;position:absolute;}.notify-hidable{cursor:pointer;}[data-notify-text],[data-notify-html]{position:relative;}.notify-arrow{position:absolute;z-index:2;width:0;height:0;}</style>
	
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','//www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-67336215-1', 'auto');
ga('send', 'pageview');

</script>
	
  </head>
  <body ng-controller="mainCtrl">

	<audio id="start-game-sound" src="/sounds/game-start.mp3" preload="auto"></audio>
	<audio id="new-item-sound" src="/sounds/Stavka-1.mp3" preload="auto"></audio> 
	<audio id="tik-sound1" src="/sounds/click.mp3" preload="auto"></audio>
	<audio id="tik-sound2" src="/sounds/click.mp3" preload="auto"></audio>
	<audio id="tik-sound3" src="/sounds/click.mp3" preload="auto"></audio>

	<div class="wrapper-main">
		<header class="header-main">

			<div class="header-main-center"> 
				<a href="/#/" class="logo"></a>
<?php
					if(!isset($_SESSION['steamid'])) { 
						?>
				<div class="wrapper-logo-login">
					<div class="profile-block profile-block_2" ng-class="{'show': !auth }">
						<a  href="/logger.php?login" class="login-with-steam-button">Войти через Steam</a>
						<div class="clear"></div>
					</div>
					        <?php } else { 

						include ('steamauth/userInfo.php');
						?>

					<div class="login-info-block" ng-class="{'show': auth}">
						<div class="info-pofil">
							<div class="info-pofil-player">
								<div class="info-pofil-player-icon">
								<img class="avatar-img" ng-src="{{ auth.avatarfull }}" alt="{{ auth.personaname }}" />
								</div>
								
								<p class="name-player-login">{{ auth.personaname }}</p>
								
								<div class="clear"></div>
							</div> 

							<!-- <div class="info-pofil-balance">
								<p class="info-pofil-balance-text">Баланc:</p>
								<p class="info-pofil-balance-sum">56 525руб.</p>
							</div> -->

							<a href="/steamauth/logout.php" class="button-header-logout">Выход</a>

							<div class="clear"></div>          
						</div>

						<div class="wrapper-profil-button">
							<ul>
								<li><a ng-click="openProfileModal()">Профиль</a></li>
								<li><a href="/#/my/inventory">Инвентарь</a></li>
								<li><a href="/#/my/history">История</a></li>
							</ul>
							<div class="clear"></div>
						</div>

						<div class="wrapper-link">
							<button type="submit" class="wrapper-link-button-i" ng-click="saveTradeLink()"></button>
							<input rel="get-trade-link" type="text" name="link" placeholder="Введите ссылку..." class="wrapper-link-input-i" ng-model="auth.tradelink" ng-value="{{auth.tradelink}}">

							<a class="wrapper-link-i" href="http://steamcommunity.com/id/id/tradeoffers/privacy#trade_offer_access_url" target="_blank"><img src="img/znak.png" alt="question"></a>
						</div>

						<div class="clear"></div>
					</div>
						<?php 

					}?>
					<div class="clear"></div>
				</div>

				<div class="wrapper-main-menu">
					<ul>
						<li><a href="/#/" ng-click="updateTimer()">играть</a></li>
						<li><a href="/#/top">топ игроков</a></li>
						<li><a href="/#/history">история</a></li>
						<li><a href="/#/about">о сайте</a></li>
						<li><a href="" ng-click="openFairModal()">честная игра</a></li>
						<li><a href="" ng-click="openSupportModal()">поддержка</a></li>
					</ul>
					<div class="clear"></div>
				</div>
		</header>

		<ng-view></ng-view>
	</div>
<?php if(!isset($_SESSION['steamid'])) {
$detailsWrapClass = 'hidden';
$enterClass = ''; 
$text_game = ''; 
?>
	<script type="text/javascript">
				var authInit = false;
			</script>
<?php } else {
                                $text_game = ''; 
                                $detailsWrapClass = '';
                                $enterClass = 'hidden'; 
                                
 ?>
	<script type="text/javascript">
				var authInit = {
            'steamid' : '<?php echo $steamprofile['steamid'];?>',
            'personaname' : '<?php echo $steamprofile['personaname'];?>',
            'profileurl' : '<?php echo $steamprofile['profileurl'];?>',
            'avatar' : '<?php echo $steamprofile['avatar'];?>',
            'avatarmedium' : '<?php echo $steamprofile['avatarmedium'];?>',
            'avatarfull' : '<?php echo $steamprofile['avatarfull'];?>',
            'realname' : '<?php echo $steamprofile['realname'];?>'
            

       };
</script>

			</script>
<?php } ?>	
	<script src="/js/angular.min.js"></script>
	<script src="/js/angular-route.js"></script>
	<script src="/js/angular-animate.js"></script>
	<script src="/js/angular-cookies.js"></script>
	<script src="/js/socket.io-1.3.5.js"></script>
	<script src="/js/ng-notify.min.js"></script>
	<script src="/js/angular-timer/angular-timer.min.js"></script>
	<script src="/js/angular-timer/humanize-duration.js"></script>
	<script src="/js/angular-timer/moment.js"></script>
	<script src="/js/lodash.min.js"></script> 
	<script src="/js/ng-websocket.js"></script>

	<script src="/js/app.js"></script>
	<script src="/js/filters/toArray.js"></script>
	<script src="/js/factories/socketFactory.js"></script>
	<script src="/js/factories/mainFactory.js"></script>
	<script src="/js/controllers/mainCtrl.js"></script>
	<script src="/js/controllers/fairplayCtrl.js"></script>
	<script src="/js/controllers/homeCtrl.js"></script>
	<script src="/js/controllers/topCtrl.js"></script>
	<script src="/js/controllers/historyCtr.js"></script>
	<script src="/js/controllers/aboutCtrl.js"></script>
	<script src="/js/controllers/gameCtrl.js"></script>
	<script src="/js/controllers/myProfileCtrl.js"></script>
	<script src="/js/controllers/myHistoryCtrl.js"></script>
	<script src="/js/controllers/myInventoryCtrl.js"></script>
	<script src="/js/controllers/supportCtrl.js"></script>
	<script src="/js/controllers/rouletteCtrl.js"></script>
	<script src="/js/directives/loadedItems.js"></script>
	<script src="/js/directives/carousel.js"></script>
	<script src="/js/directives/roulette.js"></script>
	<script src="/js/swiper.js"></script>
	<script src="/js/angular-swiper.js"></script>
	<script src="/js/angular-translate.min.js"></script>
	<script src="/js/ngDialog.min.js"></script>
	</body>
</html>